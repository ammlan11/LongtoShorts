"""Minimal in-memory job manager. This is a single-user local tool — no
database, no auth, no multi-tenancy. Each job now runs in two background-
thread phases instead of one:

  1. analyze  — download (if from a URL) + transcribe + find candidate
                highlights, then stop and wait ("awaiting_review").
  2. render   — triggered separately once the user has reviewed/edited the
                candidate list and picked a caption/aspect style; only then
                do the (slow) ffmpeg passes actually run.

Splitting it this way is what lets the UI show "here are 5 possible shorts,
pick/edit the ones you want" before spending render time on any of them.
"""
from __future__ import annotations

import copy
import logging
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .config import AppConfig
from .pipeline.presets import CUSTOM_PRESET_ID, get_aspect_preset, get_caption_preset, hex_to_ass
from .pipeline.render import analyze_video, render_selected

logger = logging.getLogger("shorts_ai.jobs")

# queued -> downloading -> analyzing -> awaiting_review -> rendering -> done
#                                                                     \-> error
STATUSES = (
    "queued", "downloading", "analyzing", "awaiting_review",
    "rendering", "done", "error",
)


@dataclass
class Job:
    id: str
    job_dir: Path
    cfg: AppConfig
    video_path: Optional[Path] = None
    status: str = "queued"
    stage: str = ""
    progress: float = 0.0
    error: Optional[str] = None
    analysis: Optional[dict[str, Any]] = None   # candidates, from analyze_video()
    summary: Optional[dict[str, Any]] = None    # final shorts, from render_selected()
    heatmap: Optional[list[dict[str, Any]]] = None  # YouTube "most replayed" data, if any
    # Per-stage wall-clock seconds (download/transcribing/finding_highlights),
    # filled in as the job runs — surfaced in the API response so a slow run
    # can actually be diagnosed (which stage ate the time) instead of guessed
    # at from a single "it took 30 minutes" report.
    timing: dict[str, float] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)


class JobManager:
    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    # ---- phase 1: analyze -------------------------------------------------

    def create_job(self, video_path: Path, overrides: dict[str, Any] | None = None) -> Job:
        job = self._new_job()
        job.video_path = video_path
        cfg = self._apply_overrides(overrides)
        job.cfg = cfg
        thread = threading.Thread(target=self._run_analyze, args=(job,), daemon=True)
        thread.start()
        return job

    def create_job_from_url(self, url: str, overrides: dict[str, Any] | None = None) -> Job:
        """Same as create_job, but the source video is downloaded first
        (yt-dlp) — used by the 'paste a link' path in the UI."""
        job = self._new_job()
        job.stage = "downloading"
        cfg = self._apply_overrides(overrides)
        job.cfg = cfg
        thread = threading.Thread(target=self._run_download_then_analyze, args=(job, url), daemon=True)
        thread.start()
        return job

    def _new_job(self) -> Job:
        job_id = uuid.uuid4().hex[:12]
        job_dir = self.cfg.jobs_dir / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        job = Job(id=job_id, job_dir=job_dir, cfg=self.cfg)
        with self._lock:
            self._jobs[job_id] = job
        return job

    def _apply_overrides(self, overrides: dict[str, Any] | None) -> AppConfig:
        cfg = self.cfg
        if not overrides:
            return cfg
        cfg = copy.deepcopy(cfg)
        if overrides.get("clip_count"):
            cfg.highlights.clip_count = int(overrides["clip_count"])
        if "captions_enabled" in overrides:
            cfg.captions.enabled = bool(overrides["captions_enabled"])
        if "overlays_enabled" in overrides:
            cfg.overlays.enabled = bool(overrides["overlays_enabled"])
        if "use_llm" in overrides:
            cfg.highlights.use_llm = bool(overrides["use_llm"])
        return cfg

    def _run_download_then_analyze(self, job: Job, url: str) -> None:
        job.status = "downloading"
        job.stage = "downloading"
        job.progress = 0.0
        try:
            from .pipeline.youtube import download_video

            def dl_progress(pct: float):
                job.progress = pct

            result = download_video(url, self.cfg.uploads_dir, progress_cb=dl_progress)
            job.video_path = result.path
            job.heatmap = result.heatmap
            job.timing["download_seconds"] = round(result.download_seconds, 1)
            logger.info("Job %s: download took %.1fs", job.id, result.download_seconds)
        except Exception as e:  # noqa: BLE001 — surface any failure to the UI
            logger.error("Job %s failed to download %s: %s", job.id, url, e)
            job.status = "error"
            job.error = str(e)
            return
        self._run_analyze(job)

    def _run_analyze(self, job: Job) -> None:
        job.status = "analyzing"
        # Tracks wall-clock time per named stage (transcribing,
        # finding_highlights, ...) by watching for the stage name to change
        # between progress_cb calls — gives concrete per-stage numbers in
        # job.timing without needing analyze_video() itself to know about
        # timing at all.
        stage_tracker = {"stage": None, "started": None}

        def _flush_stage(now: float) -> None:
            if stage_tracker["stage"] is not None:
                key = f"{stage_tracker['stage']}_seconds"
                job.timing[key] = round(job.timing.get(key, 0.0) + (now - stage_tracker["started"]), 1)

        try:
            def progress_cb(stage: str, pct: float):
                now = time.monotonic()
                if stage_tracker["stage"] != stage:
                    _flush_stage(now)
                    stage_tracker["stage"] = stage
                    stage_tracker["started"] = now
                job.stage = stage
                job.progress = pct

            analysis = analyze_video(
                job.video_path, job.job_dir, job.cfg, progress_cb=progress_cb, heatmap=job.heatmap
            )
            _flush_stage(time.monotonic())
            analysis["timing"] = dict(job.timing)
            total = sum(job.timing.values())
            logger.info("Job %s: stage timing %s (total %.1fs)", job.id, job.timing, total)
            job.analysis = analysis
            job.status = "awaiting_review"
            job.stage = "awaiting_review"
            job.progress = 1.0
        except Exception as e:  # noqa: BLE001 — surface any failure to the UI
            logger.error("Job %s failed to analyze: %s\n%s", job.id, e, traceback.format_exc())
            job.status = "error"
            job.error = str(e)

    # ---- phase 2: render ----------------------------------------------------

    def start_render(
        self,
        job_id: str,
        selections: list[dict[str, Any]],
        caption_preset: str | None = None,
        aspect_preset: str | None = None,
        caption_overrides: dict[str, Any] | None = None,
    ) -> Optional[Job]:
        """Kicks off the render phase for a job that's sitting in
        'awaiting_review'. `selections` is the (possibly user-edited) list of
        candidates to actually render — see render_selected() for the shape.
        Returns None if the job doesn't exist or isn't ready to be rendered.

        `caption_overrides` is the "Custom" style panel's field-by-field
        tweaks (position/font_size/text_color/highlight_color/background_box)
        — applied on top of whichever named preset was picked (or the
        default one, if caption_preset is the "custom" sentinel / omitted),
        so picking "Custom" and only moving the font-size slider doesn't
        reset everything else to defaults."""
        job = self._jobs.get(job_id)
        if job is None or job.status != "awaiting_review":
            return None
        if not selections:
            return None

        cfg = copy.deepcopy(job.cfg)
        if caption_preset and caption_preset != CUSTOM_PRESET_ID:
            style = get_caption_preset(caption_preset)
            cfg.captions.font = style["font"]
            cfg.captions.font_size = style["font_size"]
            cfg.captions.highlight_color = style["highlight_color"]
            cfg.captions.base_color = style["base_color"]
            cfg.captions.outline_color = style["outline_color"]
            cfg.captions.back_color = style["back_color"]
            cfg.captions.position = style["position"]
            cfg.captions.border_style = style["border_style"]
            cfg.captions.outline_width = style["outline_width"]
            cfg.captions.shadow_width = style["shadow_width"]
            cfg.captions.preset = caption_preset

        if caption_overrides:
            co = caption_overrides
            if co.get("position") in ("lower_third", "center", "top"):
                cfg.captions.position = co["position"]
            if co.get("font_size"):
                try:
                    cfg.captions.font_size = max(24, min(140, int(co["font_size"])))
                except (TypeError, ValueError):
                    pass
            if co.get("text_color"):
                cfg.captions.base_color = hex_to_ass(co["text_color"])
            if co.get("highlight_color"):
                cfg.captions.highlight_color = hex_to_ass(co["highlight_color"])
            if "background_box" in co:
                if co["background_box"]:
                    cfg.captions.border_style = 3
                    cfg.captions.outline_width = 0
                    cfg.captions.shadow_width = 0
                    cfg.captions.back_color = "&HD0161616"
                else:
                    cfg.captions.border_style = 1
                    cfg.captions.outline_width = 5
                    cfg.captions.shadow_width = 2
            cfg.captions.preset = CUSTOM_PRESET_ID

        if aspect_preset:
            aspect = get_aspect_preset(aspect_preset)
            cfg.reframe.target_aspect = aspect_preset
            cfg.reframe.target_width = aspect["width"]
            cfg.reframe.target_height = aspect["height"]
        job.cfg = cfg

        thread = threading.Thread(target=self._run_render, args=(job, selections), daemon=True)
        thread.start()
        return job

    def _run_render(self, job: Job, selections: list[dict[str, Any]]) -> None:
        job.status = "rendering"
        job.progress = 0.0
        try:
            def progress_cb(stage: str, pct: float):
                job.stage = stage
                job.progress = pct

            summary = render_selected(job.video_path, job.job_dir, job.cfg, selections, progress_cb=progress_cb)
            job.summary = summary
            job.status = "done"
            job.progress = 1.0
        except Exception as e:  # noqa: BLE001 — surface any failure to the UI
            logger.error("Job %s failed to render: %s\n%s", job.id, e, traceback.format_exc())
            job.status = "error"
            job.error = str(e)

    def get(self, job_id: str) -> Optional[Job]:
        return self._jobs.get(job_id)
