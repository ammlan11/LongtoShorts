# Shorts AI

Turn a long-form video into several YouTube-Shorts-ready vertical clips:
auto-detected highlight moments, smart 9:16 (or square / 4:5) reframing
that follows the speaker's face, animated word-by-word captions in a style
you pick, and auto-generated stat cards / bar charts for any numbers you
mention. It's a small local web app — you run it on your own machine, open
a browser tab, drop in a video, **review a shortlist of candidate moments
and tweak them**, then render just the ones you actually want.

Everything runs locally. Transcription uses an open-source Whisper model
(via `faster-whisper`) that downloads once and then runs fully offline.
Highlight selection and stat detection use plain heuristics by default; if
you install [Ollama](https://ollama.com) and pull a model, the tool will
use it to sharpen the highlight picks and titles — but nothing here calls
a paid API or needs an API key.

## How it works: analyze, then review, then render

The tool deliberately splits into two steps instead of one black-box
"upload and wait":

1. **Analyze** — transcribe the video (local Whisper) and score a shortlist
   of candidate moments (more than you'll likely use — typically 5-8).
   This is the slow step, and it only happens once.
2. **Review & render** — you see every candidate with its time range,
   suggested title, and the plain-language reasons it was picked. Uncheck
   the ones you don't want, nudge the start/end of any you do, retitle
   them, pick a caption style and aspect ratio, then render. Only the
   clips you actually confirm get the (much faster, but still not free)
   full render pass — cutting, reframing, overlays, and caption burn-in.

That split is what makes "review and edit before rendering" possible
without re-transcribing every time you change your mind about which clips
to keep.

## What the pipeline actually does, per clip

1. **Transcribe** — word-level timestamps from the video's audio (local Whisper), cached per job so re-rendering with different picks/styles never re-transcribes.
2. **Find highlights** — scores sliding windows of the transcript for hook
   strength, concrete numbers, pacing, and engagement language; snaps clip
   boundaries to sentence starts/ends. If Ollama is running, it also asks
   your local LLM to pick the best candidates and write short titles.
3. **Reframe** — detects the speaker's face frame-by-frame (OpenCV) and pans
   a cropped window to follow them, instead of a static center-crop that
   can cut people off. Target aspect ratio (9:16, 1:1, or 4:5) is whatever
   you pick at the review step.
4. **Stat overlays** — scans the transcript for numbers ("90%", "twenty two
   thousand dollars", etc.) and drops in a stat card, or a small comparison
   bar chart when two related numbers appear close together — positioned in
   the upper third so they never collide with captions. Hand-drawn with
   Pillow — no plotting library dependency.
5. **Captions** — word-by-word animated captions (the current word
   highlighted), burned in via ffmpeg, in whichever of the caption style
   presets you picked (see below).

Each candidate comes with a plain-language "why this clip" explanation
(e.g. *"opens with a hook", "contains 3 concrete numbers", "energetic,
well-paced delivery"*) so the picks aren't a black box.

## Caption styles & aspect ratios

Three built-in caption presets (`app/pipeline/presets.py`), picked at the
review step:

- **Bold highlight** — white text, the current word pops in amber. The classic short-form look.
- **Clean white** — plain bold white text, no per-word color change, thinner outline.
- **Boxed** — white text on a solid dark background box instead of an outline.

And three aspect ratio presets: **9:16** (Shorts/Reels/TikTok), **1:1**
(square feed post), **4:5** (Instagram portrait).

## Requirements

- Python 3.10-3.12 (see the note below — this specifically matters here)
- [ffmpeg](https://ffmpeg.org/) on your PATH (`ffmpeg -version` to check)
- For captions: your ffmpeg needs subtitle (libass) support. On macOS,
  Homebrew's default `ffmpeg` formula does **not** include it — if you hit a
  caption burn-in error, run `brew install ffmpeg-full` (installs alongside
  your existing ffmpeg; the app auto-detects and uses it). `setup.sh` checks
  for this and warns you up front.
- ~2-4 GB RAM free for the transcription model (more for larger model sizes)
- Optional, for sharper highlight picks: [Ollama](https://ollama.com/download)
  running locally with a model pulled (e.g. `ollama pull llama3.1`)

No GPU required — everything defaults to CPU. If you do have an NVIDIA GPU,
see the `transcription.device` setting in `config.yaml`.

**Why the Python version matters:** `faster-whisper` depends on PyAV, which
needs prebuilt wheels for your exact Python version — on a brand-new Python
(3.13+) that may not exist yet, which forces pip into a source build that
can fail with cryptic C compiler errors if your system's ffmpeg dev headers
don't line up with what PyAV's build expects. Python 3.10-3.12 is the
tested, known-good range. `setup.sh` below checks this for you automatically.

## Setup

The easy way — this checks for ffmpeg, picks a safe Python version if more
than one is installed, creates the virtual environment, and installs
everything:

```bash
cd shorts-ai
./setup.sh
```

Or by hand, if you'd rather:

```bash
cd shorts-ai
python3.12 -m venv .venv          # see the Python version note above
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

The first time you transcribe a video, `faster-whisper` downloads the model
weights from Hugging Face (a few hundred MB for the default `small` model).
After that, transcription is fully offline.

## Run it

```bash
source .venv/bin/activate   # if not already active
python run.py
```

Then open **http://localhost:8000**:

1. Drop in a video file, or click **Paste a link** and give it a YouTube
   (or other yt-dlp-supported site) URL — it downloads locally first, then
   runs the same pipeline. Set how many candidates to find and whether to
   use captions / overlays / the local LLM, then click **Find shorts**.
2. Once analysis finishes, you'll see every candidate moment with its
   timing, title, and reasons. Uncheck anything you don't want, edit
   start/end times or titles inline, pick a caption style and aspect
   ratio, then click **Render selected**.
3. Watch each finished short with a preview player, its reasons, and a
   download button. **Make more** takes you back to step 1 for another
   video.

Only paste links to video you actually have the right to download and
repurpose — your own uploads, or anything whose license/terms allow it.
The tool doesn't and can't check that for you.

## Configuration

Defaults live in `config.yaml` at the project root — model size, clip
length bounds, caption styling, overlay theme, Ollama connection, etc. Each
option is commented inline. Caption/aspect *presets* (what the review step's
pickers offer) live separately in `app/pipeline/presets.py`. A few worth
knowing about:

- `transcription.model_size`: `tiny` is fastest (lower accuracy), `small` is
  the default balance, `medium`/`large-v3` are much more accurate but slower
  on CPU. Bump this up if you have the hardware.
- `highlights.use_llm`: if `true` and Ollama isn't reachable, the tool just
  silently falls back to the heuristic scorer — nothing breaks.
- `highlights.clip_count`: how many candidates the analyze step tries to
  surface for review (the UI asks for more than this to always have a
  handful of real options — see `analyze_video()` in `render.py`).
- `reframe.smoothing_window`: higher = steadier pans, lower = crop reacts
  faster to movement.
- `overlays.theme`: `dark` or `light` card style for the stat/graph overlays.

## Project layout

```
shorts-ai/
├── setup.sh                 preflight + venv + install (recommended)
├── run.py                   entrypoint (starts the web server)
├── config.yaml              all tunable settings
├── app/
│   ├── main.py               FastAPI routes (upload, presets, render, poll, download)
│   ├── jobs.py                background job runner — analyze -> awaiting_review -> render lifecycle
│   ├── config.py              config loading
│   ├── static/                 the single-page frontend (upload -> review -> results)
│   └── pipeline/
│       ├── transcribe.py      local Whisper wrapper (with transcript caching)
│       ├── highlights.py      heuristic + optional-LLM highlight scoring
│       ├── presets.py         caption style + aspect ratio presets
│       ├── reframe.py         face-tracked crop to the chosen aspect ratio
│       ├── captions.py        word-level animated .ass captions
│       ├── overlays.py        stat-card / chart detection + Pillow rendering
│       ├── palette.py         the color palette used in generated graphics
│       ├── llm.py             optional local Ollama client
│       ├── youtube.py         yt-dlp wrapper for the "paste a link" path
│       └── render.py          analyze_video() + render_selected(): the two pipeline phases
└── scripts/
    ├── make_test_video.py        generates a synthetic test clip
    ├── test_pipeline_offline.py  pipeline-level smoke test (analyze_video + render_selected directly)
    └── test_api_e2e.py           full HTTP API smoke test (upload -> review -> render -> download)
```

## Known limitations (roadmap ideas, not blockers)

- Face tracking uses a classic Haar-cascade detector — reliable for a
  front-facing talking head, less so for side angles, screen-share footage,
  or multiple people. It falls back to a steady center-crop when no face is
  found, so output is never broken, just less "smart" in those cases.
- The stat-overlay extractor is regex/keyword-based, not a full NLP model —
  it catches most digit and spelled-out numbers ("90%", "twenty percent",
  "$5,000", "five thousand dollars") but can occasionally miss unusual
  phrasing or misfire on a number that isn't actually a meaningful stat.
- Long-form sources: processing time scales with video length mostly during
  the transcription step (the one-time analyze phase). A 60-minute video on
  `small`/CPU takes roughly the video's own runtime, give or take, depending
  on your machine. The render phase (per selected clip) is much faster.

## Testing without downloading a model

- `scripts/test_pipeline_offline.py` exercises `analyze_video()` and
  `render_selected()` directly — candidate generation, a simulated
  review-step edit, style presets, cutting, reframing, overlays, and
  captions — using a hand-built transcript, so you can sanity-check the
  pipeline without waiting on a model download.
- `scripts/test_api_e2e.py` drives the actual HTTP API end to end (upload,
  poll for candidates, submit an edited selection + style choice, poll for
  the render, download the result) using FastAPI's test client.
- `scripts/make_test_video.py` generates the synthetic source clip both of
  the above use.
